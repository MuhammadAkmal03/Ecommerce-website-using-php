<?php
require "includes/common.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>About Us | Shopify</title>
    <link rel="shortcut icon" href="img/srtcticon.png" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    <br>
    <div class="container">
    <div class="row">
        <div class="col-md-6 about-content" style="border: 5px solid #ccc; padding: 20px;">
            <h2 style="color: #8c52ff;">About Us</h2>
            <p>Welcome to Shopify, your go-to destination for all your shopping needs. We are a dedicated team passionate about providing a seamless and enjoyable shopping experience. Our mission is to connect you with top-quality products, great deals, and exceptional customer service.</p>
            <p>At Shopify, we believe that shopping should be convenient, reliable, and secure. That's why we partner with trusted sellers who share our commitment to quality and customer satisfaction. Our diverse range of products spans various categories, ensuring that you'll find exactly what you're looking for.</p>
            <p>Whether you're a fashion enthusiast, a gadget lover, or simply in need of home essentials, Shopify has got you covered. We continually strive to enhance our platform, offering an intuitive interface, detailed product information, and competitive prices.</p>
        </div>
        <div class="col-md-6">
           
        </div>
    </div>
</div>


    <?php include 'includes/footer.php'; ?>
</body>
</html>
