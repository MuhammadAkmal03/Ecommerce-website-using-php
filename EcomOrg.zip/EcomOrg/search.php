<div class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">
                <h2 style="color: black; margin: 0; padding-top: 0px;">
                    SHOPI<span style="color: #8c52ff;">FY</span>
                </h2>
            </a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <form action="search.php" method="GET" class="navbar-form">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                            </div>
                        </div>
                    </form>
                </li>
                <?php
                if (isset($_SESSION['email'])) {
                    ?>
                    <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="settings.php"><span class="glyphicon glyphicon-user"></span> User</a></li>
                    <li><a href="logout_script.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
                    <?php
                } else {
                    ?>
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#loginmodal"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                    <li><a href="about_us.php"><span class="glyphicon glyphicon-th-list"></span> About Us</a></li>
                    <li><a href="contact_us.php"><span class="glyphicon glyphicon-phone"></span> Contact Us</a></li>
                    <?php
                }
                ?>
            </ul>
        </div>
    </div>
</div>

<?php
// Retrieve the search query
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Perform necessary sanitization on the search query

// Replace the placeholders with your actual database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL statement with a prepared statement
$sql = "SELECT * FROM items WHERE name LIKE ?";
$stmt = $conn->prepare($sql);

// Bind the search query to the prepared statement
$searchParam = "%" . $searchQuery . "%";
$stmt->bind_param("s", $searchParam);

// Execute the prepared statement
$stmt->execute();

// Get the result set
$result = $stmt->get_result();

// Process the search results
if ($result->num_rows > 0) {
    echo '<h2>Search Results</h2>'; // Added title for search results

    // Display the search results
    while ($row = $result->fetch_assoc()) {
        // Output the search results using the same format as on the product page
        echo '<div class="col-sm-4 home-feature">';
        echo '<div class="thumbnail">';
        echo '<div class="caption">';
        echo '<h3>' . $row["name"] . '</h3>'; 
        echo '<p>Price: Rs. ' . $row["price"] . '</p>';
        
        // Add to Cart and Buy Now buttons
        echo '<div class="btn-group">';
        if (!isset($_SESSION['email'])) {
            echo '<a href="success.php" data-toggle="modal" data-target="#loginmodal" role="button" class="btn btn-primary">Buy Now</a>';
        } else {
            if (check_if_added_to_cart($row["id"])) {
                echo '<a href="#" class="btn btn-success disabled">Added to Cart</a>';
            } else {
                echo '<a href="cart-add.php?id=' . $row["id"] . '" class="btn btn-primary">Add to Cart</a>';
            }
        }
        echo '</div>'; // End of btn-group div
        
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo '<h2>No results found.</h2>'; // Added message for no search results
}

// Close the prepared statement and the database connection
$stmt->close();
$conn->close();
?>
