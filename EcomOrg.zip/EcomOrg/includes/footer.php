<?php
        include 'includes/modal.php';
        ?>
<footer>
    <div class="container">
        <div class="row">
            <div class="columnf">
              <h3>More</h3>
                <p><a href="about_us.php"><span style="color:white">About Us</span></a></p>
                <p><a href="contact_us.php"><span style="color:white">Contact Us</span></a></p>
            </div>

            <div class="columnf">
              <h3>My Account</h3>
                <p><a href="#" data-toggle="modal" data-target="#loginmodal" ><span style="color:white">Log In</span></a></p>
                <p><a href="signup.php"><span style="color:white">Sign Up</span></a></p>
            </div>

            <div class="columnf">       
                <h3 style="color :#8c52ff">Shopify</h3>
            </div>
        </div>
        
    </div>
</footer>
